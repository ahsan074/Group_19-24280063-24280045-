import pandas as pd
import matplotlib.pyplot as plt
from prefect import task, flow, get_run_logger

# Step 1: Fetch Data
@task
def fetch_data(file_path: str):
    logger = get_run_logger()
    logger.info(f"Reading data from {file_path}...")
    df = pd.read_csv(file_path)
    logger.info(f"Data shape: {df.shape}")
    return df

# Step 2: Validate Data
@task
def validate_data(df: pd.DataFrame):
    logger = get_run_logger()
    logger.info("Validating data...")
    missing_values = df.isnull().sum()
    logger.info(f"Missing values:\n{missing_values}")
    # Drop rows with missing values
    df_clean = df.dropna()
    logger.info(f"Data shape after cleaning: {df_clean.shape}")
    return df_clean

# Step 3: Transform Data
@task
def transform_data(df: pd.DataFrame):
    logger = get_run_logger()
    logger.info("Transforming data...")
    if "sales" in df.columns:
        df["sales_normalized"] = (df["sales"] - df["sales"].mean()) / df["sales"].std()
        logger.info("Normalized 'sales' column.")
    return df

# Step 4: Generate Analytics Report
@task
def generate_report(df: pd.DataFrame):
    logger = get_run_logger()
    logger.info("Generating analytics report...")
    summary = df.describe()
    summary.to_csv("data/analytics_summary.csv")
    logger.info("Summary statistics saved to data/analytics_summary.csv")
    return "data/analytics_summary.csv"

# Step 5: Create Histogram for Sales Distribution
@task
def create_histogram(df: pd.DataFrame):
    logger = get_run_logger()
    logger.info("Creating histogram for sales distribution...")
    if "sales" in df.columns:
        plt.hist(df["sales"], bins=20)
        plt.title("Sales Distribution")
        plt.xlabel("Sales")
        plt.ylabel("Frequency")
        plt.savefig("data/sales_histogram.png")
        plt.close()
        logger.info("Sales histogram saved to data/sales_histogram.png")
    return "data/sales_histogram.png"

# Define the flow to orchestrate the tasks
@flow
def analytics_pipeline(file_path: str):
    df = fetch_data(file_path)
    df_clean = validate_data(df)
    df_transformed = transform_data(df_clean)
    report = generate_report(df_transformed)
    histogram = create_histogram(df_transformed)

    # Optionally return results or save to files
    return {"report": report, "histogram": histogram}

# Run the flow
if __name__ == "__main__":
    analytics_pipeline("analytics_data.csv")
